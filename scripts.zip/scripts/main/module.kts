@file:Depends("coreMindustry")

package main

name = "Main Module"
/**
 * 简单脚本请在该模块下编写
 */