@file:Depends("coreMindustry")

package teaching

name = "teaching Module"
/**
 * 用于教学的模块
 */