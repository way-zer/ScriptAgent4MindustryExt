@file:Depends("coreMindustry")

package translate

name = "translate"
/**
 * 翻译模块
 */