package wayzer.lib.dao.util

@MustBeDocumented
annotation class WithTransactionHelper

